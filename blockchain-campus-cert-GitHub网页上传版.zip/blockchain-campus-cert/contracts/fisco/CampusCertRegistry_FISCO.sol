pragma solidity ^0.4.25;

/**
 * FISCO BCOS 存证合约（接口示意，适用于 WeBASE / Console 部署）
 *
 * 说明：
 *   FISCO BCOS 官方推荐使用 Solidity 0.4.25 / 0.6.10 版本编译，
 *   本文件给出与 CampusCertRegistry.sol 等价的、符合国密改造环境的最小接口映射，
 *   便于在联盟链环境中落地。实际部署时表结构由 FISCO 的 CRUD 接口编译为链上表。
 */

contract CampusCertRegistryFISCO {

    // 机构白名单
    mapping(address => bool) private issuers;

    struct Record {
        string materialId;
        string studentHash;
        uint8  materialType;
        string dataHash;
        uint64 version;
        uint64 updatedAt;
        address issuer;
        uint8  status; // 1 ACTIVE / 2 REVOKED
    }

    // 使用 bytes32 key 做索引，兼容 FISCO 的 KV 存储
    mapping(bytes32 => Record) private records;

    event RegisterEvt(string materialId, string dataHash, string studentHash, uint64 ts);
    event UpdateEvt(string materialId, string newDataHash, uint64 version, uint64 ts);
    event RevokeEvt(string materialId, string reason, uint64 ts);

    constructor() public {
        issuers[msg.sender] = true;
    }

    modifier onlyIssuer() {
        require(issuers[msg.sender], "not issuer");
        _;
    }

    function addIssuer(address a) public {
        issuers[a] = true;
    }

    function register(
        string materialId,
        string studentHash,
        uint8  materialType,
        string dataHash
    ) public onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        require(bytes(records[key].dataHash).length == 0, "exists");
        records[key] = Record(materialId, studentHash, materialType, dataHash, 1, uint64(now), msg.sender, 1);
        emit RegisterEvt(materialId, dataHash, studentHash, uint64(now));
    }

    function update(
        string materialId,
        string newDataHash
    ) public onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        Record storage r = records[key];
        require(bytes(r.dataHash).length > 0, "not found");
        require(r.status == 1, "not active");
        r.dataHash = newDataHash;
        r.version += 1;
        r.updatedAt = uint64(now);
        emit UpdateEvt(materialId, newDataHash, r.version, uint64(now));
    }

    function revoke(string materialId, string reason) public onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        Record storage r = records[key];
        require(bytes(r.dataHash).length > 0, "not found");
        r.status = 2;
        r.updatedAt = uint64(now);
        emit RevokeEvt(materialId, reason, uint64(now));
    }

    function verify(string materialId, string candidateHash) public view
        returns (bool matched, string onChainHash, uint8 status)
    {
        bytes32 key = keccak256(bytes(materialId));
        Record storage r = records[key];
        if (bytes(r.dataHash).length == 0) {
            return (false, "", 0);
        }
        return (
            keccak256(bytes(r.dataHash)) == keccak256(bytes(candidateHash)),
            r.dataHash,
            r.status
        );
    }
}
