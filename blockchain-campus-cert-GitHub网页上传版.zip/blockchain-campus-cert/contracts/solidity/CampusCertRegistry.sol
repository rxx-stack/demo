// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title CampusCertRegistry
 * @notice 校园学生信息与学业资料防篡改存证合约（原型）
 *
 * 设计原则：
 *   1. 链上只存"哈希指纹 + 元数据"，绝不存明文（成绩、身份证号等敏感信息一律留在链下）。
 *   2. 每条资料以 materialId 为主键，支持同一学生多类资料共存。
 *   3. 采用"登记 - 变更 - 撤销"三段式状态机，任何修改都必须留痕，历史版本不可删除。
 *   4. 通过授权机制控制谁有权代学生写入资料（仅白名单机构）。
 */

contract CampusCertRegistry {

    /* ========================= 数据结构 ========================= */

    // 资料类型枚举：学籍、成绩单、学历学位、奖惩、竞赛证书、综合素质
    enum MaterialType {
        ENROLLMENT,     // 0 学籍信息
        TRANSCRIPT,     // 1 成绩单
        DEGREE,         // 2 学历学位证
        REWARD,         // 3 奖惩记录
        CERTIFICATE,    // 4 竞赛/技能证书
        PROFILE         // 5 综合素质档案
    }

    // 资料状态
    enum Status {
        NONE,       // 0 不存在
        ACTIVE,     // 1 有效
        REVOKED,    // 2 已撤销
        SUPERSEDED  // 3 已被新版本取代
    }

    // 单条资料存证记录
    struct MaterialRecord {
        string  materialId;     // 资料唯一编号（如 2021-CS-0001-TRANSCRIPT）
        string  studentHash;    // 学号哈希（不存明文学号）
        uint8   materialType;   // 资料类型
        string  dataHash;       // 资料原文的哈希指纹（SM3/SHA-256）
        string  metadataURI;    // 链下元数据地址（可选，指向 IPFS/校内存储）
        uint64  version;        // 版本号，从 1 开始
        uint64  issuedAt;       // 出具时间戳
        uint64  updatedAt;      // 最近变更时间戳
        address issuer;         // 出具机构地址
        uint8   status;         // 当前状态
    }

    // 版本历史（不可删除，构成完整追溯链）
    struct VersionRecord {
        uint64  version;
        string  dataHash;
        uint64  updatedAt;
        address operator;
        string  changeReason;   // 变更原因（成绩复核、学位补授等）
    }

    /* ========================= 状态变量 ========================= */

    address public admin;                                   // 系统管理员（如信息化中心）
    mapping(address => bool) public authorizedIssuers;      // 机构白名单
    mapping(bytes32 => MaterialRecord) private records;     // materialId-hash => 记录
    mapping(bytes32 => VersionRecord[]) private history;    // 版本历史
    mapping(bytes32 => bool) public materialExists;

    uint256 public totalRecords;                            // 累计存证条数（统计用）

    /* ========================= 事件 ========================= */

    event IssuerUpdated(address indexed issuer, bool allowed);
    event MaterialRegistered(
        string  materialId,
        string  studentHash,
        uint8   materialType,
        string  dataHash,
        address indexed issuer,
        uint64  timestamp
    );
    event MaterialUpdated(
        string  materialId,
        uint64  newVersion,
        string  newDataHash,
        address indexed operator,
        string  reason,
        uint64  timestamp
    );
    event MaterialRevoked(
        string  materialId,
        address indexed operator,
        string  reason,
        uint64  timestamp
    );

    /* ========================= 修饰器 ========================= */

    modifier onlyAdmin() {
        require(msg.sender == admin, "CR: caller is not admin");
        _;
    }

    modifier onlyIssuer() {
        require(authorizedIssuers[msg.sender], "CR: caller is not an authorized issuer");
        _;
    }

    constructor() {
        admin = msg.sender;
        authorizedIssuers[msg.sender] = true;
    }

    /* ========================= 管理接口 ========================= */

    /// @notice 增删机构白名单（仅管理员）
    function setIssuer(address issuer, bool allowed) external onlyAdmin {
        authorizedIssuers[issuer] = allowed;
        emit IssuerUpdated(issuer, allowed);
    }

    /* ========================= 核心存证接口 ========================= */

    /**
     * @notice 登记一条新的学生资料存证
     * @param materialId   资料唯一编号
     * @param studentHash  学号哈希
     * @param materialType 资料类型枚举
     * @param dataHash     资料原文哈希指纹
     * @param metadataURI  链下元数据地址
     * @param issuedAt     出具时间
     */
    function registerMaterial(
        string calldata materialId,
        string calldata studentHash,
        uint8  materialType,
        string calldata dataHash,
        string calldata metadataURI,
        uint64 issuedAt
    ) external onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        require(!materialExists[key], "CR: material already exists");
        require(bytes(dataHash).length > 0, "CR: empty data hash");
        require(materialType <= uint8(MaterialType.PROFILE), "CR: bad material type");

        uint64 nowTs = uint64(block.timestamp);

        records[key] = MaterialRecord({
            materialId:   materialId,
            studentHash:  studentHash,
            materialType: materialType,
            dataHash:     dataHash,
            metadataURI:  metadataURI,
            version:      1,
            issuedAt:     issuedAt == 0 ? nowTs : issuedAt,
            updatedAt:    nowTs,
            issuer:       msg.sender,
            status:       uint8(Status.ACTIVE)
        });

        history[key].push(VersionRecord({
            version:      1,
            dataHash:     dataHash,
            updatedAt:    nowTs,
            operator:     msg.sender,
            changeReason: "initial registration"
        }));

        materialExists[key] = true;
        totalRecords += 1;

        emit MaterialRegistered(materialId, studentHash, materialType, dataHash, msg.sender, nowTs);
    }

    /**
     * @notice 更新资料（如成绩复核后重新出具），旧版本自动归档为 SUPERSEDED
     */
    function updateMaterial(
        string calldata materialId,
        string calldata newDataHash,
        string calldata reason
    ) external onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        require(materialExists[key], "CR: material not found");
        MaterialRecord storage rec = records[key];
        require(rec.status == uint8(Status.ACTIVE), "CR: material not active");
        require(bytes(newDataHash).length > 0, "CR: empty data hash");

        uint64 nowTs = uint64(block.timestamp);
        rec.dataHash  = newDataHash;
        rec.version  += 1;
        rec.updatedAt = nowTs;
        rec.issuer    = msg.sender;

        history[key].push(VersionRecord({
            version:      rec.version,
            dataHash:     newDataHash,
            updatedAt:    nowTs,
            operator:     msg.sender,
            changeReason: reason
        }));

        emit MaterialUpdated(materialId, rec.version, newDataHash, msg.sender, reason, nowTs);
    }

    /**
     * @notice 撤销资料（如发现造假、学籍注销），记录不可删除，仅状态变更
     */
    function revokeMaterial(
        string calldata materialId,
        string calldata reason
    ) external onlyIssuer {
        bytes32 key = keccak256(bytes(materialId));
        require(materialExists[key], "CR: material not found");
        MaterialRecord storage rec = records[key];
        require(rec.status == uint8(Status.ACTIVE), "CR: material not active");

        rec.status    = uint8(Status.REVOKED);
        rec.updatedAt = uint64(block.timestamp);

        // 撤销动作同样写入历史，保证可追溯
        history[key].push(VersionRecord({
            version:      rec.version,
            dataHash:     rec.dataHash,
            updatedAt:    rec.updatedAt,
            operator:     msg.sender,
            changeReason: string(abi.encodePacked("REVOKED: ", reason))
        }));

        emit MaterialRevoked(materialId, msg.sender, reason, rec.updatedAt);
    }

    /* ========================= 验真查询接口 ========================= */

    /**
     * @notice 验真：传入待核验文件的哈希，比对链上指纹
     * @return matched  是否一致
     * @return status   链上该资料当前状态
     * @return onChainHash 链上记录的哈希
     */
    function verify(
        string calldata materialId,
        string calldata candidateHash
    ) external view returns (bool matched, uint8 status, string memory onChainHash) {
        bytes32 key = keccak256(bytes(materialId));
        if (!materialExists[key]) {
            return (false, uint8(Status.NONE), "");
        }
        MaterialRecord storage rec = records[key];
        matched     = keccak256(bytes(rec.dataHash)) == keccak256(bytes(candidateHash));
        status      = rec.status;
        onChainHash = rec.dataHash;
    }

    /// @notice 查询资料完整信息
    function getMaterial(string calldata materialId)
        external
        view
        returns (
            string memory studentHash,
            uint8  materialType,
            string memory dataHash,
            uint64 version,
            uint64 issuedAt,
            uint64 updatedAt,
            address issuer,
            uint8  status,
            uint256 versionCount
        )
    {
        bytes32 key = keccak256(bytes(materialId));
        require(materialExists[key], "CR: material not found");
        MaterialRecord storage rec = records[key];
        return (
            rec.studentHash,
            rec.materialType,
            rec.dataHash,
            rec.version,
            rec.issuedAt,
            rec.updatedAt,
            rec.issuer,
            rec.status,
            history[key].length
        );
    }

    /// @notice 查询某资料的版本历史（追溯链）
    function getHistory(string calldata materialId)
        external
        view
        returns (VersionRecord[] memory)
    {
        bytes32 key = keccak256(bytes(materialId));
        require(materialExists[key], "CR: material not found");
        return history[key];
    }

    /// @notice 校验学生哈希是否与资料归属一致（防止张冠李戴）
    function checkOwnership(
        string calldata materialId,
        string calldata studentHash
    ) external view returns (bool) {
        bytes32 key = keccak256(bytes(materialId));
        if (!materialExists[key]) return false;
        return keccak256(bytes(records[key].studentHash)) == keccak256(bytes(studentHash));
    }
}
