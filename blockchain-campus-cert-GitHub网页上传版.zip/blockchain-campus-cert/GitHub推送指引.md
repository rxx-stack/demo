# GitHub 上传完整操作指南

> **当前状态**：本地仓库已初始化完成（分支 `main`、**6 个提交**、工作区干净）✅
> **只差一步**：在 GitHub 创建一个空仓库，然后把内容传上去。

---

## 全流程一览

| 步骤 | 做什么 | 在哪里做 | 预计耗时 |
|:---:|---|---|:---:|
| 1 | 创建空仓库 | GitHub 网页 | 2 分钟 |
| 2 | **把内容传上去**（二选一） | A → GitHub 网页<br>B → 本地终端 | A: 3 分钟<br>B: 5 分钟 |
| 3 | 验证结果 | GitHub 网页 | 30 秒 |
| 4 | 完善仓库（可选） | GitHub 网页 | 3 分钟 |

### 第 2 步怎么选

| | 路线 A：网页上传 | 路线 B：命令行推送 |
|---|---|---|
| 需要装 Git | 不需要 | 需要 |
| 需要访问令牌 | 不需要 | 需要 |
| 会上传的文件 | 完全相同 | 完全相同 |
| **提交历史** | **只显示 1 次提交** | **保留完整 6 次提交** |
| 适合谁 | 只想快速传上去 | 希望仓库像真实开发过程 |

> 如果是毕业设计或课程作业，**建议走路线 B**——6 次有意义的提交（初始化 → 加脚本 → 修指引 → V2 升级 → 指引完善 → GitHub 适配）比 1 次「上传文件」更经得起看。若只是自己存档，路线 A 足够。

---

## 第 1 步：在 GitHub 创建空仓库

1. 打开 [https://github.com](https://github.com) 并登录
2. 右上角 **`+`** → **New repository**
3. 按下面填写：

| 字段 | 填什么 | 说明 |
|---|---|---|
| Repository name | `blockchain-campus-cert` | 与本地目录名一致，也可自定义 |
| Description | `基于区块链的校园学生信息与学业资料防篡改存证方案` | 一句话即可 |
| 可见性 | 选 **Public** | Private 也能推，但别人看不到 |
| Add a README file | **不勾** ⚠️ | **关键！** |
| Add .gitignore | **不勾** | 本地已有 |
| Choose a license | **不勾** | 本地已有 |

4. 点 **Create repository**

> ⚠️ **最容易踩的坑**：如果勾了「Add a README file」，GitHub 会先产生一个提交，推送时报
> `rejected - non-fast-forward`。真踩了不用重建，看文末「常见报错速查」第 ① 条。

5. 创建成功后复制仓库地址，形如：
   `https://github.com/你的用户名/blockchain-campus-cert.git`

---

## 第 2 步：把内容传上去

### 路线 A：网页上传（不用命令行）

**用到的文件**：`blockchain-campus-cert-GitHub网页上传版.zip`

1. **解压**压缩包，得到 `blockchain-campus-cert` 文件夹
2. **先在资源管理器里开启显示隐藏文件** ⚠️
   - Windows：打开文件夹 → 顶部「查看」→ 勾选 **「隐藏的项目」**
   - 原因：包里有 `.gitignore` 和 `.gitattributes` 两个**点号开头**的文件，默认看不见。漏传会导致行尾符规则失效（后续可能出现"所有文件都被改动"的假象）
3. 打开刚创建的仓库页 → 点页面上的 **uploading an existing file**（或 **Add file → Upload files**）
4. **进入** `blockchain-campus-cert` 文件夹，`Ctrl + A` 全选里面的**所有内容**（3 个文件夹 + 文件），拖到上传区
   - 注意：传的是**文件夹里面的内容**，不是文件夹本身。如果直接把外层文件夹拖进去，会多建一层目录
   - GitHub 支持直接拖拽文件夹，会自动保留目录结构
5. 页面下方 Commit changes 填：`init: 校园学业资料区块链存证方案`
6. 点 **Commit changes**

**上传后根目录结构**：

```
blockchain-campus-cert/          ← 仓库名
├── README.md                    ← 首页自动渲染成项目介绍
├── LICENSE
├── .gitattributes
├── .gitignore
├── 一键推送到GitHub.bat
├── push-to-github.sh
├── GitHub推送指引.md
├── contracts/  ├── solidity/  └── fisco/
├── demo/
└── docs/
```

> **拖拽不认文件夹怎么办**：改用「choose your files」逐个选；或先传根目录文件，再进仓库页 **Add file → Create new file** 输入 `contracts/solidity/CampusCertRegistry.sol` 这样的路径来建立目录，然后上传。

---

### 路线 B：命令行推送（保留 5 次提交历史）

**用到的文件**：`blockchain-campus-cert-GitHub仓库版.zip`（含 `.git`，可直接推送）

#### B-1 生成 Personal Access Token（GitHub 已不支持密码推送）

1. 右上角头像 → **Settings**
2. 左栏拉到最下 → **Developer settings**
3. **Personal access tokens** → **Tokens (classic)** → **Generate new token (classic)**
4. Note 填 `push`，Expiration 选 30 天（或自定义）
5. 权限**至少勾选 `repo`**（完整仓库读写）
6. 点 **Generate token** → **立即复制**（页面关闭后不再显示）

> 令牌形如 `ghp_xxxxxxxx`，B-3 步当密码用。不要截图发群里，也不要写进任何文件后上传。
> GitHub 也提供 fine-grained token（更细粒度），但 classic 配置最简单，勾 `repo` 即可。

#### B-2 关联远程仓库

在 GitHub 仓库页点绿色 **Code** 按钮 → 复制 **HTTPS** 地址。

#### B-3 推送

**方式一：双击脚本（最省事）**

1. 进入项目目录 `blockchain-campus-cert`
2. **双击 `一键推送到GitHub.bat`**
3. 提示「仓库地址：」时，粘贴 B-2 复制的地址，回车
4. 弹窗要求认证时：
   - 用户名 → 你的 GitHub 用户名
   - 密码 → **粘贴 Personal Access Token**（不是登录密码）
5. 看到 **`推送成功！`** 即完成

**方式二：手动三条命令**

```bash
# 1) 关联远程仓库（把地址换成你自己的）
git remote add origin https://github.com/你的用户名/blockchain-campus-cert.git

# 2) 确保主分支名为 main
git branch -M main

# 3) 推送
git push -u origin main
```

---

## 第 3 步：验证结果

回到仓库页刷新，确认三件事：

- [ ] 首页自动渲染出 **README**（能看到项目介绍、架构、合约接口表）
- [ ] 文件列表里有 `contracts/`、`demo/`、`docs/` 三个目录
- [ ] 提交记录：**路线 A 显示 1 条**（上传文件）／**路线 B 显示 6 条**

---

## 第 4 步：完善仓库（可选）

### 4.1 添加 Topics

仓库首页右侧 **About** → 齿轮图标 → **Topics**，填入：

```
blockchain fisco-bcos consortium-blockchain education smart-contract solidity tamper-proof
```

作用：让别人能检索到项目，答辩时也显得规范。

### 4.2 部署在线演示（GitHub Pages）

⚠️ **注意**：GitHub Pages 只能从仓库的**根目录**或 **`/docs` 目录**发布，**不能指定 `demo/` 目录**。

**做法一：用 gh-pages 分支（推荐）**

在本目录执行：

```bash
# 新建 gh-pages 分支，把演示页放到分支根目录
git checkout -b gh-pages
git checkout main -- demo/index.html
cp demo/index.html ./index.html
git rm -r --cached demo >/dev/null 2>&1
rm -rf demo
git add -A
git commit -m "chore: gh-pages 演示页"
git push -u origin gh-pages
git checkout main
```

然后到仓库 **Settings → Pages**：Source 选 `Deploy from a branch`，Branch 选 **gh-pages** / **`/ (root)`**，保存。

访问链接：`https://你的用户名.github.io/blockchain-campus-cert/`

**做法二：不部署（最省事）**

把 `demo/index.html` 下载到本地双击即可演示。该页面零依赖（无外部库、无后端），直接打开就能跑完「录入 → 哈希上链 → 模拟篡改 → 验真报警」的全流程。

---

## 常见报错速查

### ① `rejected - non-fast-forward` / `fetch first`

**原因**：创建仓库时勾了「Add a README file」，远程已有提交，与本地历史不相干。

**解决**：

```bash
git pull origin main --allow-unrelated-histories
git push -u origin main
```

若提示冲突，保留自己的文件即可；实在乱了就删掉远程仓库重建（不勾初始化）。

### ② `Authentication failed` / `Support for password authentication was removed`

**原因**：GitHub 自 2021 年起已取消账号密码推送。

**解决**：密码处填 **Personal Access Token**，权限需含 `repo`。
若之前输错过，清凭据：控制面板 → 凭据管理器 → Windows 凭据 → 删除 `github.com`。

### ③ 连接超时 / `Connection reset` / `Failed to connect to github.com`

**原因**：部分网络环境访问 GitHub 不稳定（国内常见）。

**解决**：重试几次；或改用 SSH（更稳）：

```bash
ssh-keygen -t ed25519 -C "你的邮箱"     # 一路回车
cat ~/.ssh/id_ed25519.pub               # 复制输出内容
# 粘贴到 GitHub → Settings → SSH and GPG keys → New SSH key
git remote set-url origin git@github.com:你的用户名/blockchain-campus-cert.git
git push -u origin main
```

### ④ 推送后所有文件显示「已修改」

**原因**：Windows 行尾符（CRLF）与仓库（LF）不一致。本仓库已通过 `.gitattributes` 修正，正常不会出现。

若仍出现：

```bash
git config core.autocrlf input
git rm --cached -r .
git add -A && git commit -m "chore: 统一行尾符"
```

### ⑤ 中文文件名显示为 `\346\226\207...` 乱码

**原因**：Git 默认转义非 ASCII 文件名（**不影响实际文件名**，只是显示问题）。

**解决**：

```bash
git config --global core.quotepath false
```

---

## 附录：完整命令清单（可直接复制）

```bash
# 进入项目目录
cd blockchain-campus-cert

# 关联远程（替换成你的地址）
git remote add origin https://github.com/你的用户名/blockchain-campus-cert.git

# 分支与推送
git branch -M main
git push -u origin main

# 验证
git log --oneline
git ls-remote origin
```

---

## 仓库内容清单

```
blockchain-campus-cert/
├── README.md                              # 项目说明（首页自动渲染）
├── LICENSE                                # MIT 开源协议
├── .gitignore / .gitattributes            # 忽略规则 / 行尾符规范
├── 一键推送到GitHub.bat                    # Windows 双击推送
├── push-to-github.sh                      # macOS / Linux 推送
├── GitHub推送指引.md                       # 本文件
├── contracts/
│   ├── solidity/CampusCertRegistry.sol    # 合约完整版（Solidity 0.8）
│   └── fisco/CampusCertRegistry_FISCO.sol # FISCO BCOS 适配版
├── demo/index.html                        # 可交互演示原型
└── docs/
    ├── 方案设计文档.md                     # 方案设计 V2.0（Markdown）
    └── 方案设计文档.docx                   # 方案设计 V2.0（Word 排版版）
```
