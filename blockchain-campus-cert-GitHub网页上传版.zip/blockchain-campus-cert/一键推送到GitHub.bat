@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title 推送到 GitHub - 校园学业资料区块链存证方案

echo.
echo ============================================================
echo   校园学业资料区块链存证方案 - GitHub 一键推送
echo ============================================================
echo.

REM ============================================================
REM  第 1 步：检查 Git 环境
REM ============================================================
where git >nul 2>nul
if errorlevel 1 (
    echo [错误] 未检测到 Git，请先安装 Git for Windows
    echo        下载地址：https://git-scm.com/download/win
    echo        安装时保持默认选项即可。
    echo.
    pause
    exit /b 1
)
echo [1/6] Git 环境检查通过

REM ============================================================
REM  第 2 步：确认当前目录是仓库
REM ============================================================
if not exist ".git" (
    echo [错误] 当前目录不是 Git 仓库
    echo        请把本脚本放在 blockchain-campus-cert 目录下运行。
    echo.
    pause
    exit /b 1
)
echo [2/6] 仓库目录检查通过

REM ============================================================
REM  第 3 步：输入 GitHub 仓库地址
REM ============================================================
echo.
echo ------------------------------------------------------------
echo  请粘贴你的 GitHub 仓库地址（HTTPS 格式）
echo.
echo  获取方式：打开你的 GitHub 仓库页 - 绿色 Code 按钮 - 复制 HTTPS
echo  格式示例：https://github.com/yourname/blockchain-campus-cert.git
echo ------------------------------------------------------------
echo.
set /p REPO_URL=仓库地址：

if "!REPO_URL!"=="" (
    echo.
    echo [错误] 仓库地址不能为空
    echo.
    pause
    exit /b 1
)

REM ============================================================
REM  第 4 步：配置远程仓库
REM ============================================================
git remote remove origin >nul 2>nul
git remote add origin "!REPO_URL!"
if errorlevel 1 (
    echo.
    echo [错误] 远程地址添加失败，请检查地址格式是否正确
    echo        正确格式：https://github.com/用户名/仓库名.git
    echo.
    pause
    exit /b 1
)
echo [3/6] 远程仓库已关联：!REPO_URL!

REM ============================================================
REM  第 5 步：确保分支名为 main
REM ============================================================
git branch -M main
echo [4/6] 当前分支：main

REM ============================================================
REM  第 6 步：推送
REM ============================================================
echo.
echo ------------------------------------------------------------
echo  即将推送，稍后可能弹出认证窗口
echo.
echo  用户名：你的 GitHub 用户名
echo  密码：  请填写「Personal Access Token」，不是登录密码！
echo.
echo  获取令牌：
echo    GitHub 头像 - Settings - Developer settings
echo    - Personal access tokens - Tokens (classic) - Generate new token
echo    勾选权限：repo
echo ------------------------------------------------------------
echo.
echo [5/6] 正在推送...
echo.

git push -u origin main
set PUSH_RESULT=!errorlevel!

echo.
if !PUSH_RESULT! equ 0 (
    echo ============================================================
    echo   推送成功！
    echo ============================================================
    echo.
    echo   仓库地址：!REPO_URL!
    echo.
    echo   下一步建议：
    echo     1. 打开仓库页确认 README 已自动渲染
    echo     2. 点 About 右侧齿轮，添加 Topics 标签
    echo     3. 如需在线演示：Settings - Pages - 选择 gh-pages 分支（见指引）
    echo.
    echo   推荐 Topics：
    echo     blockchain fisco-bcos consortium-blockchain education
    echo     smart-contract solidity tamper-proof
    echo.
) else (
    echo ============================================================
    echo   推送失败，请对照以下情况排查
    echo ============================================================
    echo.
    echo   [情况 1] rejected - non-fast-forward
    echo     原因：GitHub 仓库创建时勾选了「Add a README file」
    echo     解决：执行下面两条命令后，重新运行本脚本
    echo.
    echo       git pull origin main --allow-unrelated-histories
    echo       git push -u origin main
    echo.
    echo   [情况 2] Authentication failed
    echo     原因：GitHub 已取消账号密码推送
    echo     解决：密码框填写「Personal Access Token」而非登录密码
    echo         Settings - Developer settings - Personal access tokens
    echo         - Tokens (classic)，权限至少勾选 repo
    echo.
    echo   [情况 3] 连不上 / 超时 / Connection reset
    echo     原因：GitHub 在部分网络环境下连接不稳定
    echo     解决：改用 SSH 方式（见 GitHub推送指引.md）
    echo.
    echo   [情况 4] 中文文件名显示为乱码
    echo     原因：Git 默认转义非 ASCII 文件名
    echo     解决：执行 git config --global core.quotepath false
    echo.
)
echo.
pause
endlocal
