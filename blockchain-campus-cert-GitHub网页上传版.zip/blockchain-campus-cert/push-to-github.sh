#!/usr/bin/env bash
# 校园学业资料区块链存证方案 - GitHub 一键推送（macOS / Linux / Git Bash）

set -u

C_OK="\033[32m"; C_ERR="\033[31m"; C_WARN="\033[33m"; C_DIM="\033[2m"; C_OFF="\033[0m"

echo ""
echo "============================================================"
echo "  校园学业资料区块链存证方案 - GitHub 一键推送"
echo "============================================================"
echo ""

# ---------- 1. 检查 Git ----------
if ! command -v git >/dev/null 2>&1; then
    printf "${C_ERR}[错误]${C_OFF} 未检测到 Git，请先安装\n"
    echo "        macOS:  brew install git"
    echo "        Ubuntu: sudo apt install git"
    exit 1
fi
printf "${C_OK}[1/6]${C_OFF} Git 环境检查通过\n"

# ---------- 2. 检查仓库 ----------
if [ ! -d ".git" ]; then
    printf "${C_ERR}[错误]${C_OFF} 当前目录不是 Git 仓库\n"
    echo "        请 cd 到 blockchain-campus-cert 目录后再运行"
    exit 1
fi
printf "${C_OK}[2/6]${C_OFF} 仓库目录检查通过\n"

# ---------- 3. 输入仓库地址 ----------
echo ""
echo "------------------------------------------------------------"
echo " 请粘贴你的 GitHub 仓库地址（HTTPS 格式）"
echo ""
printf " ${C_DIM}获取方式：GitHub 仓库页 → 绿色 Code 按钮 → 复制 HTTPS${C_OFF}\n"
printf " ${C_DIM}格式示例：https://github.com/yourname/blockchain-campus-cert.git${C_OFF}\n"
echo "------------------------------------------------------------"
echo ""
printf "仓库地址："
read -r REPO_URL

if [ -z "$REPO_URL" ]; then
    printf "${C_ERR}[错误]${C_OFF} 仓库地址不能为空\n"
    exit 1
fi

# ---------- 4. 配置远程 ----------
git remote remove origin >/dev/null 2>&1
if ! git remote add origin "$REPO_URL"; then
    printf "${C_ERR}[错误]${C_OFF} 远程地址添加失败，请检查地址格式\n"
    echo "        正确格式：https://github.com/用户名/仓库名.git"
    exit 1
fi
printf "${C_OK}[3/6]${C_OFF} 远程仓库已关联：%s\n" "$REPO_URL"

# ---------- 5. 分支名 ----------
git branch -M main
printf "${C_OK}[4/6]${C_OFF} 当前分支：main\n"

# ---------- 6. 推送 ----------
echo ""
echo "------------------------------------------------------------"
echo " 即将推送，稍后可能需要输入认证信息"
echo ""
echo "  用户名：你的 GitHub 用户名"
echo "  密  码：请填写「Personal Access Token」，不是登录密码！"
echo ""
printf " ${C_DIM}获取令牌：GitHub 头像 → Settings → Developer settings${C_OFF}\n"
printf " ${C_DIM}          → Personal access tokens → Tokens (classic)${C_OFF}\n"
printf " ${C_DIM}勾选权限：repo${C_OFF}\n"
echo "------------------------------------------------------------"
echo ""
printf "${C_OK}[5/6]${C_OFF} 正在推送...\n\n"

if git push -u origin main; then
    echo ""
    echo "============================================================"
    printf "  ${C_OK}推送成功！${C_OFF}\n"
    echo "============================================================"
    echo ""
    echo "  仓库地址：$REPO_URL"
    echo ""
    echo "  下一步建议："
    echo "    1. 打开仓库页确认 README 已自动渲染"
    echo "    2. 点 About 右侧齿轮 → 添加 Topics"
    echo "    3. Settings → Pages → 选择 gh-pages 分支做在线演示（见指引）"
    echo ""
else
    echo ""
    echo "============================================================"
    printf "  ${C_ERR}推送失败${C_OFF}\n"
    echo "============================================================"
    echo ""
    echo "  [情况 1] rejected - non-fast-forward"
    echo "     原因：GitHub 仓库创建时勾选了「Add a README file」"
    echo "     解决："
    echo "       git pull origin main --allow-unrelated-histories"
    echo "       git push -u origin main"
    echo ""
    echo "  [情况 2] Authentication failed"
    echo "     原因：GitHub 已取消账号密码推送"
    echo "     解决：密码框填「Personal Access Token」，权限勾 repo"
    echo ""
    echo "  [情况 3] 连不上 / 超时 / Connection reset"
    echo "     原因：部分网络环境连接 GitHub 不稳定"
    echo "     解决：改用 SSH 方式"
    echo "       ssh-keygen -t ed25519 -C \"你的邮箱\""
    echo "       cat ~/.ssh/id_ed25519.pub   # 复制到 GitHub Settings - SSH and GPG keys"
    echo "       git remote set-url origin git@github.com:用户名/仓库名.git"
    echo ""
    echo "  [情况 4] 中文文件名乱码"
    echo "     解决：git config --global core.quotepath false"
    echo ""
    exit 1
fi
